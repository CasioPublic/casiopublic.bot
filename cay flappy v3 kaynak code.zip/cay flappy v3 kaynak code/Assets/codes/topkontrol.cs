﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
  
using UnityEngine.UI;
using UnityEngine.EventSystems;


public class topkontrol : MonoBehaviour , IPointerDownHandler
{
    public Rigidbody2D kutle;
    public float ziplamagücü,hiz,maxhiz,puan;
    public AudioClip ziplamasound;
    public AudioSource sescontrol;
     
    // Start is called before the first frame update
    void Start()
    {
        sescontrol = GetComponent<AudioSource>();

    }

    // Update is called once per frame
    void Update()
    {
        if (top.topyasiyormu == true)
        {
            kutle.AddForce(Vector3.right * hiz);
            if (kutle.velocity.x > maxhiz)
            {
                kutle.velocity = new Vector2(maxhiz, kutle.velocity.y);
            }
            //Debug.Log(kutle.velocity.x);
             
        }
        else
        {
            kutle.velocity = new Vector2(0, kutle.velocity.y);
        }
    }
    public void OnPointerDown(PointerEventData eventData)
    {
        if (top.topyasiyormu == true)
        {
            sescontrol.PlayOneShot(ziplamasound,0.5f);

            kutle.velocity = new Vector2(kutle.velocity.x, 0);
            kutle.AddForce(Vector3.up * ziplamagücü);
        }

    }
    public void resetlevel()
    {
        Application.LoadLevel(Application.loadedLevel);
    } 
}
