﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class top : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject resetkontrol ;
    public static bool topyasiyormu;
    public float puan,maxtimescale,timescaledeger;
    public AudioSource sescontrol;
    public AudioSource sescontrolback;
    public AudioClip olumsesi;
    public Text puanyazi,yukpuanyazi,anlikpuanyazi;
    string cayanlikst;

    void Start()
    {
        
        topyasiyormu = true;
        sescontrol = GetComponent<AudioSource>();
        cayanlikst = anlikpuanyazi.text;
         
    }

    // Update is called once per frame
    void Update()
    {
        //puan = transform.position.x;
        int maxscrtm = PlayerPrefs.GetInt("bstscr");
        if (maxscrtm < 50)
        {
            maxscrtm = 50;
        }
         timescaledeger = 1 + ((float)puan / (float)maxscrtm)*maxtimescale;
        if (timescaledeger > maxtimescale + 1)
            timescaledeger = maxtimescale + 1;
        Time.timeScale = timescaledeger;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "bicak" && topyasiyormu)
        {
            puan++;
            string anlikpuan = cayanlikst;
            anlikpuan += puan;
            anlikpuanyazi.text = anlikpuan;
        }
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "bicak" && topyasiyormu)
        {


            //parcalar.SetActive(true);

            sescontrol.PlayOneShot(olumsesi);
            sescontrolback.Pause();
            resetkontrol.SetActive(true);
            topyasiyormu = false;
            int bestscore = PlayerPrefs.GetInt("bstscr");
            if (puan < 0)
            {
                puan = 0;
            }
            if (puan > bestscore)
            {
            
                yukpuanyazi.text="" + (int)puan;
                PlayerPrefs.SetInt("bstscr", (int)puan);
            }
            else
            {
                yukpuanyazi.text = "" + bestscore;
            }
                puanyazi.text = "" + (int)puan;

            GetComponent<PolygonCollider2D>().isTrigger = true; 
            GetComponent<SpriteRenderer>().color = new Color(1,0.5f,0.5f,1);
        }
    }

}
