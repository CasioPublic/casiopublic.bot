﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class dilayari : MonoBehaviour
{
    public Text[] textler;
    public string[] stringtr;
    public string[] stringeng;
    public int dilnosu;
    public GameObject ayarlarpanel;
    public AudioSource musiccontrol, soundcontrol,soundcontrol2;
    public Toggle musictg, soundtg;
    // Start is called before the first frame update
    void Start()
    { 
        dilnosu = PlayerPrefs.GetInt("dilno");
        if (dilnosu == 1)
            PlayerPrefs.SetInt("dildefault", 1);
        if (PlayerPrefs.GetInt("dildefault") == 0 && dilnosu == 0) 
        {
            dilnosu = 1;
        }
        dilayarla(dilnosu);
        if (PlayerPrefs.GetInt("music")==0)
        {
            musiccontrol.volume = 1;
            musictg.isOn = true;
        }
        else if (PlayerPrefs.GetInt("music")==1)
        {
            musiccontrol.volume = 0;
            musictg.isOn = false;
        }
        if (PlayerPrefs.GetInt("sound") ==0)
        {
            soundcontrol.volume = 1;
            soundcontrol2.volume = 1;
            soundtg.isOn = true;
        }
        else if (PlayerPrefs.GetInt("sound") ==1)
        {
            soundcontrol.volume = 0;
            soundcontrol2.volume = 0;
            soundtg.isOn = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void dilayarla(int dilno)
    {
        PlayerPrefs.SetInt("dilno", dilno);

        if (dilno == 0)
        {
            for(int i = 0; i < textler.Length; i++)
            {
                textler[i].text = stringtr[i];
            }
        }
        else if (dilno == 1)
        {
            for(int i = 0; i < textler.Length; i++)
            {
                textler[i].text = stringeng[i];
            }
        }
    }
    public void ayarlariackapa(bool durum)
    {
        ayarlarpanel.SetActive(durum);
        
    }
    public void musickontrol()
    {
        if (musictg.isOn)
        {
            musiccontrol.volume = 1;
            PlayerPrefs.SetInt("music", 0);
        }

        else
        {
            musiccontrol.volume = 0;
            PlayerPrefs.SetInt("music", 1);
        }
    }
    public void soundkontrol()
    {
        if (soundtg.isOn)
        {
            soundcontrol.volume = 1;
            soundcontrol2.volume = 1;
            PlayerPrefs.SetInt("sound", 0);
        }

        else
        {
            soundcontrol.volume = 0;
            soundcontrol2.volume = 0;
            PlayerPrefs.SetInt("sound", 1);
        }
    }
}
