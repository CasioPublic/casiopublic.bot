﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class isinlama : MonoBehaviour
{
    public GameObject[] bicaklar;
    public GameObject duvar;
    public int bicakrastgele,deneme,eskibicak;
    public float mesafe,mesafemin,mesafemax,xkonum,topilemesafe;
    public Transform top;
    // Start is called before the first frame update
    void Start()
    {
        yenibicak();
        yenibicak();
        yenibicak();
        yenibicak();
        yenibicak();
        yenibicak();
        yenibicak();
        yenibicak();
        yenibicak();
        yenibicak();
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = new Vector3(top.position.x-topilemesafe, top.position.y, top.position.z);
    }
    public void rastgelebicak()
    {
        bicakrastgele = Random.Range(0, bicaklar.Length);
        mesafe = Random.Range(mesafemin, mesafemax);
        if (Mathf.Abs( eskibicak - bicakrastgele )> bicaklar.Length / 2 && mesafe < mesafemax / 2 && bicakrastgele < 11 && deneme<15)
        {
            deneme += 1;
            rastgelebicak();
        }
    
    }
    public void yenibicak()
    {
        mesafe = Random.Range(mesafemin, mesafemax);
        //Debug.Log(mesafe);
        xkonum = xkonum + mesafe;
        //Debug.Log(xkonum);
        bicakrastgele = Random.Range(0, bicaklar.Length);
        eskibicak = bicakrastgele;
        Instantiate(bicaklar[bicakrastgele], new Vector3(xkonum, 0, 0), Quaternion.Euler(0, 0, 0));
       
    }
   
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "bicak")
        {
            Destroy(collision.gameObject);
            yenibicak();
        }
        if (collision.tag == "duvar")
        {
            
            Instantiate(collision.gameObject, new Vector3(transform.position.x, collision.transform.position.y, 0), Quaternion.Euler(0, 0, 0));
            Destroy(collision.gameObject);
        }
  
    }



}
